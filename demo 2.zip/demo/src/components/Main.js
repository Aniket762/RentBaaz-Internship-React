import React from "react";
import { motion } from "framer-motion";

const Main = () => {
  return (
    <motion.div
      className="main"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.3, delay: 1 }}
    >
      <div className="main-top">
        <img
          src="https://images.unsplash.com/photo-1414235077428-338989a2e8c0?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=500&q=60"
          alt="this is chill"
        />
        <div className="main-navs d-flex ">
          <button className="mr-2">Casual Dining</button>
          <button>Bar</button>
        </div>
      </div>
      <div className="main-content">
        <p>
          Socials <span>5km</span>
        </p>
      </div>
      <div className="main-cards">
        <div className="container d-flex">
          <motion.div
            initial={{ y: "100vh", opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ duration: 0.5, delay: 1 }}
            className="main-card text-center d-flex justify-content-center flex-column"
          >
            <h5>Happy Hour</h5>
            <p>9:00 PM</p>
          </motion.div>
          <motion.div
            className="main-card text-center d-flex justify-content-center flex-column"
            initial={{ y: "100vh", opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ duration: 0.5, delay: 1.2 }}
          >
            <h5>Comedy Night</h5>
            <p>9:00 PM</p>
          </motion.div>
        </div>
      </div>
    </motion.div>
  );
};

export default Main;
