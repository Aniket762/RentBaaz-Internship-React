import React from "react";
import LandingCard from "./LandingCard";

const AllCards = () => {
  return (
    <section className="landing__cards">
      <h2>Bengalaru</h2>
      <div className="container pt-4">
        <div className="row">
          <div className="col-12">
            <LandingCard
              title={"indigo XP"}
              subTitle={"Indiranagar"}
              img={
                "https://images.unsplash.com/photo-1525159831892-59d292d558b4?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=500&q=60"
              }
            />
          </div>
          <div className="col-12">
            <LandingCard
              title={"indigo XP"}
              subTitle={"Indiranagar"}
              img={
                "https://images.unsplash.com/photo-1563396984259-c296a53e3c24?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=500&q=60"
              }
            />
          </div>
          <div className="col-12">
            <LandingCard
              title={"right here"}
              subTitle={"there it goes"}
              img={
                "https://images.unsplash.com/photo-1563396984259-c296a53e3c24?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=500&q=60"
              }
            />
          </div>
        </div>
      </div>
    </section>
  );
};

export default AllCards;
