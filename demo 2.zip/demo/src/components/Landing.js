import React from "react";
import LandingHeader from "./LandingHeader";
import LandingContent from "./LandingContent";
import AllCards from "./AllCards";

const Landing = () => {
  return (
    <div id="landing" className="text-center">
      <LandingHeader />
      <LandingContent />
      <AllCards />
    </div>
  );
};
export default Landing;
