import React from "react";
import { motion } from "framer-motion";

const LandingContent = () => {
  return (
    <div className="landing__content">
      <motion.div
        initial={{ x: "100vh", opacity: 0 }}
        animate={{ x: 0, opacity: 1 }}
        transition={{ duration: 0.5, delay: 0.5 }}
      >
        <h4>Exiting places around you</h4>
        <h6>
          Lorem, ipsum dolor sit amet consectetur adipisicing elit. Illum,
          praesentium.
        </h6>
      </motion.div>

      <motion.img
        initial={{ y: "100vh", opacity: 0, scale: 0 }}
        animate={{ y: "-0", opacity: 1, scale: 1 }}
        transition={{ duration: 0.5, delay: 1 }}
        src="https://image.freepik.com/free-vector/travelers-concept-illustration_114360-2602.jpg"
        alt=""
        className="img-fluid"
      />
    </div>
  );
};

export default LandingContent;
