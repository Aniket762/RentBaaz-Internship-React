import React from "react";
import { Link } from "react-router-dom";
import { motion } from "framer-motion";

const LandingCard = ({ img, title, subTitle }) => {
  return (
    <Link to="/detail">
      <motion.div className="card landing__card">
        <img src={img} className="img-fluid" alt="dining-tables" />
        <div className="card-body">
          <h5 className="card-title">{title}</h5>
          <p className="card-text">{subTitle}</p>
        </div>
      </motion.div>
    </Link>
  );
};

export default LandingCard;
