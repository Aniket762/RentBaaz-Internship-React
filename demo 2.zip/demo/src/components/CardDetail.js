import React from "react";
import Main from "./Main";
import { motion } from "framer-motion";

const CardDetail = () => {
  return (
    <div className="card-detail mb-4 ">
      <motion.form
        initial={{ y: "-100vh", opacity: 0, scale: 0 }}
        animate={{ y: "0", opacity: 1, scale: 1 }}
        transition={{ duration: 0.5 }}
      >
        <div className="container">
          <div className="form-group">
            <img src="../search-solid.svg" alt="" />
            <input
              type="text"
              className="form-control"
              placeholder="Your Favourite Dish"
            />
          </div>
        </div>
      </motion.form>
      <div className="banner d-flex justify-content-around align-items-center">
        <motion.h4
          className="m-0 p-0"
          initial={{ x: "-100vw", opacity: 0 }}
          animate={{ x: "0", opacity: 1 }}
          transition={{ duration: 0.5, delay: 0.2 }}
        >
          Church Street
        </motion.h4>
        <motion.span
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.5, delay: 0.2 }}
        ></motion.span>
        <motion.h4
          className="m-0 p-0"
          initial={{ x: "100vw", opacity: 0 }}
          animate={{ x: "0", opacity: 1 }}
          transition={{ duration: 0.5, delay: 0.2 }}
        >
          Birthday Party
        </motion.h4>
      </div>
      <Main />
      <Main />
    </div>
  );
};

export default CardDetail;
