import React from "react";
import CardDetail from "./CardDetail";

const RenderCard = () => {
  return (
    <>
      <CardDetail />
    </>
  );
};

export default RenderCard;
