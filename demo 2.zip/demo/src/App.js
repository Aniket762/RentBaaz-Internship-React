import React from "react";
import { BrowserRouter as Router, Route } from "react-router-dom";
import Landing from "./components/Landing";
import RenderCards from "./components/RenderCards";

function App() {
  return (
    <div className="App">
      <Router>
        <Route path="/" exact component={Landing} />
        <Route path="/detail" exact component={RenderCards} />
      </Router>
    </div>
  );
}

export default App;
